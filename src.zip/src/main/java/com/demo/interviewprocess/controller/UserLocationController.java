package com.demo.interviewprocess.controller;


import com.demo.interviewprocess.entity.UserLocation;
import com.demo.interviewprocess.repository.UserLocationRepository;
import com.demo.interviewprocess.service.UserLocationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@RestController
@Slf4j
@Validated
public class UserLocationController {

    @Autowired
    UserLocationRepository userLocationRepository;

    @Autowired
    UserLocationService userLocationService;

    @PostMapping
    @RequestMapping("/create_data")
    @ResponseStatus(HttpStatus.CREATED)
    public void create_data(@Validated @RequestBody UserLocation userLocation) {
        log.info(":: create table :: started");
        //TODO
        // JPA create table while running
    }

    @PutMapping
    @RequestMapping("/update_data")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<UserLocation> update_date(@Validated @RequestBody UserLocation userLocation) {
        log.info(":: Update Data :: started");
        return new ResponseEntity<>(userLocationRepository.save(userLocation), HttpStatus.OK);
    }


    @GetMapping
    @RequestMapping("/getUser/{count}")
    public ResponseEntity<List<UserLocation>> getUsers(@PathVariable int count) {
        log.info(":: fetch list::");
        List<UserLocation> userLocationList = userLocationRepository.findByExcludedFalse();
        log.info(":: excluded count :: list size : "+userLocationList.size());
        Collections.sort(userLocationList, Comparator.comparing(x -> userLocationService.getDistance(x.getLatitude(),x.getLongitude())));
        log.info(":: comparator done :: list size : "+userLocationList.size());
        return new ResponseEntity<>(userLocationList.subList(0,count), HttpStatus.OK);
    }


}
