package com.demo.interviewprocess.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

    private static final String READER = "READER";
    private static final String ADMIN = "ADMIN";

    // Create 2 users for demo
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {

        auth.inMemoryAuthentication()
                .withUser(READER).password("{noop}password").roles(READER)
                .and()
                .withUser(ADMIN).password("{noop}password").roles(READER, ADMIN);

    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http
                //HTTP Basic authentication
                .httpBasic()
                .and()
                .authorizeRequests()
                .antMatchers(HttpMethod.GET, "/getUser/**").hasRole(READER)
                .antMatchers(HttpMethod.POST, "/update_data").hasRole(ADMIN)
                .antMatchers(HttpMethod.PUT, "/created_data").hasRole(ADMIN)
                .and()
                .csrf().disable()
                .formLogin().disable();
    }
}