package com.demo.interviewprocess.service;

import org.springframework.stereotype.Service;

@Service
public class UserLocationService {

    public double getDistance(double latitude, double longitude){
        return Math.sqrt((Math.pow(latitude,2))+(Math.pow(longitude,2)));
    }
}
