package com.demo.interviewprocess.controller;

import com.demo.interviewprocess.entity.UserLocation;
import com.demo.interviewprocess.repository.UserLocationRepository;
import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class UserLocationControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    private UserLocationRepository userLocationRepository;

    @Before("")
    public void init(){
        List<UserLocation>  userLocationList = new ArrayList<>();
        UserLocation userLocation = new UserLocation();
        userLocation.setExcluded(false);
        userLocation.setName("Test1");
        userLocation.setLatitude(1.2);
        userLocation.setLongitude(2.1);
        userLocationList.add(userLocation);
        when(userLocationRepository.findByExcludedFalse()).thenReturn(userLocationList);
    }

    @Test
    void create_data() {
    }

    @Test
    void update_date() {
    }

    @Test
    void getUsers() throws Exception {

    }
}